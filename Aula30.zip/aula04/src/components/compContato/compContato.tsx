const compContato = () => {
  return (
    <>
        <h1>Contato</h1>
    </>
  )
}

export default compContato;