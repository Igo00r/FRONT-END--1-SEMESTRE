const Footer = () => {
    return (
      <>
        <header>
          <h1>Rodapé</h1>
        </header>
      </>
    )
  }
  
  export default Footer;
  