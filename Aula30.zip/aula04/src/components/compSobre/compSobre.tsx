const compSobre = () => {
  return (
    <>
        <h1>Sobre</h1>
    </>
  )
}

export default compSobre;
