const Header = () => {
    return (
      <>
        <header>
          <h1>Cabeçalho</h1>
        </header>
      </>
    )
  }
  
  export default Header;
  