const Produto = () => {
    return (
      <>
          <h1>Produto</h1>
      </>
    )
  }
  
  export default Produto;
  