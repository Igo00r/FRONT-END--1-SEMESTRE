const Home = () => {
  return (
    <>
        <h1>Página Inicial</h1>
    </>
  )
}

export default Home;